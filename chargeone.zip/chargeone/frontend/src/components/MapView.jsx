import React, { useEffect, useRef } from 'react';
import L from 'leaflet';

const STATUS_COLOR = { AVAILABLE: '#A3E635', BUSY: '#F59E0B', OCCUPIED: '#F59E0B', CHARGING: '#22D3EE', FAULT: '#EF4444', OFFLINE: '#64748B', MAINTENANCE: '#F59E0B' };

const boltSvg = (fill) => `<svg viewBox="0 0 24 24" fill="${fill}" xmlns="http://www.w3.org/2000/svg"><path d="M13 2 4.5 14H11l-1.5 8L18 10h-6.5L13 2z"/></svg>`;

export function markerIcon(status, pulse = false) {
  const c = STATUS_COLOR[status] || '#64748B';
  const dark = status === 'OFFLINE';
  return L.divIcon({
    className: `co-marker ${pulse && status === 'AVAILABLE' ? 'pulse' : ''}`,
    html: `<div class="pin" style="background:${c}">${boltSvg(dark ? '#CBD5E1' : '#0B1220')}</div>`,
    iconSize: [26, 26], iconAnchor: [13, 13], popupAnchor: [0, -14],
  });
}

export default function MapView({ stations = [], center = [19.076, 72.8777], zoom = 11, height = '100%', onSelect, selectedId, fit = false, route = null, className = '', pulse = true, userPos = null }) {
  const elRef = useRef(null);
  const mapRef = useRef(null);
  const layerRef = useRef(null);
  const routeRef = useRef(null);
  const userRef = useRef(null);

  useEffect(() => {
    if (mapRef.current) return;
    const map = L.map(elRef.current, { zoomControl: true, attributionControl: true }).setView(center, zoom);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap &copy; CARTO', maxZoom: 19,
    }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    setTimeout(() => map.invalidateSize(), 200);
    return () => { map.remove(); mapRef.current = null; };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (map) map.setView(center, zoom);
  }, [center[0], center[1], zoom]);

  useEffect(() => {
    const layer = layerRef.current, map = mapRef.current;
    if (!layer || !map) return;
    layer.clearLayers();
    stations.forEach(s => {
      const m = L.marker([s.lat, s.lng], { icon: markerIcon(s.status, pulse && s.id === selectedId ? true : pulse && s.status === 'AVAILABLE') });
      const c = s.counts || {};
      m.bindPopup(`
        <div style="min-width:190px">
          <div style="font-weight:800;font-size:13px">${s.name}</div>
          <div style="color:#94A3B8;font-size:11px;margin:2px 0 6px">${s.operatorName || ''} · ${s.city || ''}</div>
          <div style="display:flex;gap:6px;font-size:11px;font-weight:700">
            <span style="color:#A3E635">● ${c.available ?? 0} free</span>
            <span style="color:#F59E0B">● ${c.occupied ?? 0} busy</span>
            <span style="color:#EF4444">● ${c.fault ?? 0} fault</span>
          </div>
          <div style="margin-top:6px;font-size:11px;color:#94A3B8">Health <b style="color:${(s.health ?? 0) >= 80 ? '#A3E635' : '#F59E0B'}">${s.health ?? '—'}/100</b> · ₹${s.pricePerKwh}/kWh · up to ${s.maxPower} kW</div>
        </div>`);
      m.on('click', () => onSelect && onSelect(s));
      layer.addLayer(m);
    });
    if (fit && stations.length) {
      map.fitBounds(L.latLngBounds(stations.map(s => [s.lat, s.lng])).pad(0.15));
    }
  }, [stations, selectedId, fit, onSelect, pulse]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (routeRef.current) { routeRef.current.remove(); routeRef.current = null; }
    if (route && route.length > 1) {
      const g = L.layerGroup().addTo(map);
      L.polyline(route, { color: '#334155', weight: 6, opacity: .7 }).addTo(g);
      L.polyline(route, { color: '#A3E635', weight: 2.5, className: 'energy-flow' }).addTo(g);
      routeRef.current = g;
      map.fitBounds(L.latLngBounds(route).pad(0.2));
    }
  }, [JSON.stringify(route)]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (userRef.current) { userRef.current.remove(); userRef.current = null; }
    if (userPos) {
      const g = L.layerGroup().addTo(map);
      L.circle([userPos.lat, userPos.lng], { radius: Math.min(userPos.accuracy || 60, 500), color: '#38BDF8', weight: 1, opacity: 0.4, fillColor: '#38BDF8', fillOpacity: 0.07 }).addTo(g);
      L.marker([userPos.lat, userPos.lng], {
        icon: L.divIcon({ className: 'user-loc', html: '<div class="ring"></div><div class="dot"></div>', iconSize: [18, 18], iconAnchor: [9, 9] }),
        zIndexOffset: 1000,
      }).bindPopup('<b>You are here</b><br/><span style="color:#94A3B8;font-size:11px">Live location</span>').addTo(g);
      userRef.current = g;
    }
  }, [userPos?.lat, userPos?.lng]);

  return <div ref={elRef} style={{ height, width: '100%' }} className={`rounded-2xl border border-line overflow-hidden z-0 ${className}`} />;
}
