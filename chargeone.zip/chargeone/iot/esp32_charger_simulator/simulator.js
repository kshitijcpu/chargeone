#!/usr/bin/env node
/**
 * ChargeOne — ESP32 charger node simulator (Node.js version)
 * Use this when no physical ESP32 is on hand. It behaves exactly like the
 * firmware in esp32_charger_simulator.ino: sends a telemetry frame every 5 s
 * and lets you change the charger status from the keyboard.
 *
 *   node simulator.js [chargerId] [backendUrl]
 *   e.g. node simulator.js CH_30 http://localhost:4000
 *
 * Keys:  1 ONLINE · 2 AVAILABLE · 3 CHARGING · 4 FAULT · 5 OFFLINE · 6 MAINTENANCE · q quit
 */
const CHARGER_ID = process.argv[2] || 'CH_30';
const BASE = process.argv[3] || 'http://localhost:4000';
const STATUSES = ['ONLINE', 'AVAILABLE', 'CHARGING', 'FAULT', 'OFFLINE', 'MAINTENANCE'];
let status = 'AVAILABLE';
let energy = 0;

async function send() {
  const charging = status === 'CHARGING';
  const v = charging ? +(380 + Math.random() * 22).toFixed(1) : 0;
  const a = charging ? +(44 + Math.random() * 8).toFixed(1) : 0;
  const kw = charging ? +((v * a) / 1000).toFixed(2) : 0;
  if (charging) energy += kw * (5 / 3600);
  const frame = {
    charger_id: CHARGER_ID,
    station_id: 'ST_202',
    status,
    voltage: v,
    current: a,
    power_kw: kw,
    energy_kwh: +energy.toFixed(3),
    connector: 'CCS2',
    connector_status: charging ? 'LOCKED' : 'UNLOCKED',
    temperature: +(30 + Math.random() * 8).toFixed(1),
    fault: status === 'FAULT' ? 'E-310 COMM_TIMEOUT' : null,
  };
  try {
    const res = await fetch(`${BASE}/api/iot/telemetry`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(frame),
    });
    const d = await res.json();
    console.log(`[${new Date().toLocaleTimeString()}] ${status.padEnd(12)} → ${res.status} ${d.ok ? '✓ platform updated' : d.error || ''} ${charging ? `(${kw} kW, ${energy.toFixed(2)} kWh)` : ''}`);
  } catch (e) {
    console.log('✗ backend unreachable:', e.message);
  }
}

console.log(`⚡ ChargeOne ESP32 simulator — charger ${CHARGER_ID} → ${BASE}`);
console.log('Keys: 1 ONLINE · 2 AVAILABLE · 3 CHARGING · 4 FAULT · 5 OFFLINE · 6 MAINTENANCE · q quit\n');

process.stdin.setRawMode?.(true);
process.stdin.resume();
process.stdin.on('data', (k) => {
  const s = k.toString();
  if (s === 'q' || s === '\u0003') process.exit(0);
  const i = parseInt(s, 10) - 1;
  if (STATUSES[i]) {
    status = STATUSES[i];
    if (status !== 'CHARGING') energy = 0;
    console.log(`>> status changed to ${status}`);
    send();
  }
});

send();
setInterval(send, 5000);
