/*
 * ChargeOne — ESP32 Charger Node Simulator
 * ----------------------------------------
 * Simulates a real EV charge point controller for the competition demo.
 * Publishes telemetry frames to the ChargeOne backend over HTTP
 * (production path: MQTT over TLS with per-device credentials).
 *
 * Hardware demo mapping (optional):
 *   GPIO 25 -> GREEN LED  (AVAILABLE)
 *   GPIO 26 -> BLUE LED   (CHARGING)
 *   GPIO 27 -> RED LED    (FAULT)
 *   GPIO 32 -> Push button: cycle status  ONLINE -> AVAILABLE -> CHARGING -> FAULT -> OFFLINE -> MAINTENANCE
 *
 * When the button changes status, the whole ChargeOne platform —
 * user map, station page, operator console, admin live map —
 * updates in real time via the backend's WebSocket fan-out.
 */
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// ---------- CONFIG ----------
const char* WIFI_SSID   = "YOUR_WIFI";
const char* WIFI_PASS   = "YOUR_PASS";
const char* BACKEND_URL = "http://<backend-host>:4000/api/iot/telemetry";
const char* CHARGER_ID  = "CH_30";     // demo charger: Mumbai Airport T2, CCS2-01
const char* STATION_ID  = "ST_202";

const int PIN_GREEN = 25, PIN_BLUE = 26, PIN_RED = 27, PIN_BTN = 32;

const char* STATUSES[] = {"ONLINE", "AVAILABLE", "CHARGING", "FAULT", "OFFLINE", "MAINTENANCE"};
int statusIdx = 1;
float energyKwh = 0.0;
unsigned long lastSend = 0, lastDebounce = 0;

void setLeds() {
  digitalWrite(PIN_GREEN, statusIdx == 1);
  digitalWrite(PIN_BLUE,  statusIdx == 2);
  digitalWrite(PIN_RED,   statusIdx == 3);
}

void sendTelemetry() {
  if (WiFi.status() != WL_CONNECTED) return;

  StaticJsonDocument<384> doc;
  doc["charger_id"] = CHARGER_ID;
  doc["station_id"] = STATION_ID;
  doc["status"]     = STATUSES[statusIdx];
  doc["connector"]  = "CCS2";

  if (statusIdx == 2) {               // CHARGING — realistic DC fast-charge envelope
    float v = 380 + random(0, 220) / 10.0;   // 380–402 V
    float a = 44 + random(0, 80) / 10.0;     // 44–52 A
    float kw = v * a / 1000.0;
    energyKwh += kw * (5.0 / 3600.0);        // 5 s tick
    doc["voltage"]  = v;
    doc["current"]  = a;
    doc["power_kw"] = kw;
    doc["energy_kwh"] = energyKwh;
    doc["temperature"] = 34 + random(0, 60) / 10.0;
    doc["fault"] = nullptr;
  } else if (statusIdx == 3) {        // FAULT
    doc["voltage"] = 0; doc["current"] = 0; doc["power_kw"] = 0;
    doc["fault"] = "E-310 COMM_TIMEOUT";
    doc["temperature"] = 31.2;
  } else {
    doc["voltage"] = 0; doc["current"] = 0; doc["power_kw"] = 0;
    doc["fault"] = nullptr;
    doc["temperature"] = 30.5;
    energyKwh = 0;
  }

  String body;
  serializeJson(doc, body);

  HTTPClient http;
  http.begin(BACKEND_URL);
  http.addHeader("Content-Type", "application/json");
  // Production: http.addHeader("Authorization", "Bearer <device-token>");
  int code = http.POST(body);
  Serial.printf("[%s] POST %d  %s\n", STATUSES[statusIdx], code, body.c_str());
  http.end();
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_GREEN, OUTPUT); pinMode(PIN_BLUE, OUTPUT); pinMode(PIN_RED, OUTPUT);
  pinMode(PIN_BTN, INPUT_PULLUP);
  setLeds();

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) { delay(400); Serial.print("."); }
  Serial.println("\nConnected: " + WiFi.localIP().toString());
}

void loop() {
  // Button: cycle charger status (debounced)
  if (digitalRead(PIN_BTN) == LOW && millis() - lastDebounce > 400) {
    lastDebounce = millis();
    statusIdx = (statusIdx + 1) % 6;
    setLeds();
    Serial.printf(">> Status changed to %s\n", STATUSES[statusIdx]);
    sendTelemetry();                  // push immediately so the site updates instantly
  }

  if (millis() - lastSend > 5000) {   // heartbeat every 5 s
    lastSend = millis();
    sendTelemetry();
  }
}
